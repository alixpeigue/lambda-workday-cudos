import boto3
import psycopg2

def lambda_handler(event, context):
    ...